# Do not import any additional 3rd party external libraries as they will not
# be available to AutoLab and are not needed (or allowed)

import numpy as np
from resampling import *

class Conv1d_stride1():
    def __init__(self, in_channels, out_channels, kernel_size,
                 weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size

        if weight_init_fn is None:
            self.W = np.random.normal(0, 1.0, (out_channels, in_channels, kernel_size))
        else:
            self.W = weight_init_fn(out_channels, in_channels, kernel_size)

        if bias_init_fn is None:
            self.b = np.zeros(out_channels)
        else:
            self.b = bias_init_fn(out_channels)

        self.dLdW = np.zeros(self.W.shape)
        self.dLdb = np.zeros(self.b.shape)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
            ex.(2,10,203)

        ex. W shape is  (5, 10, 4)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
            ex.(2, 5, 200)
        """
        self.A = A
        #print("A is ",A)
        batch_size=self.A.shape[0]
        weight_out_channels=self.W.shape[0]
        input_size=self.A.shape[2]
        self.input_size=input_size
        output_size=((input_size-self.kernel_size)//1)+1
        Z = np.zeros((batch_size,weight_out_channels,output_size)) # Gets correct shape of (2, 5, 200)
        # for i in range(output_size):
        #     Z[:,:,i]=np.tensordot(A[:,:,i:i+self.kernel_size],self.W,axes=([1,2],[1,2]))+1          batch size: 3, input size: 66. Fail to return correct forward values
        for batch in range(batch_size):
            for woc in range(weight_out_channels):
                for k in range(output_size):
                    Z[batch,woc,k]=np.multiply(A[batch,:,k:k+self.kernel_size],self.W[woc,:,:]).sum()
                bias=self.b[woc]
                Z[batch,woc]+=bias
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        self.dLdb = np.sum(dLdZ, axis=(0, 2))
        batch_size=dLdZ.shape[0]
        output_size=dLdZ.shape[2]

        for batch in range(batch_size):
            for oc in range(self.out_channels):
                for ic in range(self.in_channels):
                    for i in range(self.kernel_size):
                        for j in range(output_size):
                            self.dLdW[oc, ic, i] += self.A[batch, ic, i + j] * dLdZ[batch, oc, j]

        dLdA = np.zeros(self.A.shape)
        for batch in range(batch_size):
            for ic in range(self.in_channels):
                for oc in range(self.out_channels):
                    for i in range((self.input_size - self.kernel_size) + 1):
                        for j in range(self.kernel_size):
                            dLdA[batch, ic, i + j] += dLdZ[batch, oc, i] * self.W[oc, ic, j]
        return dLdA

class Conv1d():
    def __init__(self, in_channels, out_channels, kernel_size, stride,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify the variable names
    
        self.stride = stride
        # Initialize Conv1d() and Downsample1d() isntance
        self.conv1d_stride1 = Conv1d_stride1(in_channels, out_channels, kernel_size,
                 weight_init_fn=None, bias_init_fn=None) # TODO

        self.downsample1d = Downsample1d(downsampling_factor=self.stride) # TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """
        Z = self.conv1d_stride1.forward(A) # TODO
        Z=self.downsample1d.forward(Z)
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        # Call downsample1d backward
        dLdZ=self.downsample1d.backward(dLdZ)
        # Call Conv1d_stride1 backward
        dLdA = self.conv1d_stride1.backward(dLdZ) # TODO 
        return dLdA


class Conv2d_stride1():
    def __init__(self, in_channels, out_channels,
                 kernel_size, weight_init_fn=None, bias_init_fn=None):

        # Do not modify this method

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size

        if weight_init_fn is None:
            self.W = np.random.normal(0, 1.0, (out_channels, in_channels, kernel_size, kernel_size))
        else:
            self.W = weight_init_fn(out_channels, in_channels, kernel_size, kernel_size)

        if bias_init_fn is None:
            self.b = np.zeros(out_channels)
        else:
            self.b = bias_init_fn(out_channels)

        self.dLdW = np.zeros(self.W.shape)
        self.dLdb = np.zeros(self.b.shape)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        self.A = A
        batch_size=self.A.shape[0]
        weight_out_channels=self.W.shape[0]
        input_width=A.shape[2]
        input_height=A.shape[3]
        output_width=((input_width-self.kernel_size)//1)+1
        output_height=((input_height-self.kernel_size)//1)+1
        #print("output_size is", output_size) 
        Z = np.zeros((batch_size,weight_out_channels,output_width,output_height)) # Gets correct shape of (2, 5, 200)

        for batch in range(batch_size):
            for woc in range(weight_out_channels):
                for i in range(output_width):
                    for j in range(output_height):
                        Z[batch,woc,i,j]=np.multiply(A[batch,:,i:i+self.kernel_size,j:j+self.kernel_size],self.W[woc,:,:,:]).sum()
                    bias=self.b[woc]
                    Z[batch,woc]+=bias
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        # print(dLdZ.shape)
        self.dLdb = np.sum(dLdZ, axis=(0, 2,3))
        # print("dLdb shape is ",self.dLdb.shape) #correct dimension. Returns (6,)
        # self.dLdb = np.sum(dLdZ, axis=(1, 2,3))
        # print("dLdb shape is ",self.dLdb.shape)
        # self.dLdb = np.sum(dLdZ, axis=(2,3))
        # print("dLdb shape is ",self.dLdb.shape)
        # self.dLdb = np.sum(dLdZ, axis=(3))
        # print("dLdb shape is ",self.dLdb.shape)
        width=self.A.shape[2]
        height=self.A.shape[3]
        output_width=dLdZ.shape[2]
        output_height=dLdZ.shape[3]
        # print("A shape is ",self.A.shape)
        # print("output width is ",output_width)
        # print("output height is ",output_height)
        # print("value of i range is ",width-output_width+1)
        # print("value1 of j range is ",height-output_height+1)
        # for i in range(width-output_width+1):
        #     for j in range(height-output_height+1):
        
        for i in range(self.dLdW.shape[2]):
            for j in range(self.dLdW.shape[3]):
                # print("self.A[:,:,i:i+output_Width,j:j+output_width] shape is ",self.A[:,:,i:i+output_width,j:j+output_height].shape)
                # print("dLdZ shape is ",dLdZ.shape)
                # print("dLdW shape that we want after tensordot is ",self.dLdW[:,:,i,j].shape)
                self.dLdW[:,:,i,j]+= np.tensordot(dLdZ,self.A[:,:,i:i+output_width,j:j+output_height],axes=[(0,2,3),(0,2,3)]).reshape(self.dLdW[:,:,i,j].shape)           

        dLdA=np.zeros(self.A.shape)
        weight_width=self.W.shape[2]
        weight_height=self.W.shape[3]
        # print("dLdZ shape is ",dLdZ.shape)
        # dLdZ=np.pad(dLdZ, ((0,0),(0,0),(self.kernel_size//2,self.kernel_size//2),(self.kernel_size//2,self.kernel_size//2)),mode='constant',constant_values=0)
        dLdZ=np.pad(dLdZ, ((0,0),(0,0),(self.kernel_size-1,self.kernel_size-1),(self.kernel_size-1,self.kernel_size-1)),mode='constant',constant_values=0)
        flipped_weight=np.flip(self.W, (2, 3))
        # for i in range(output_width-weight_width+1):
        for i in range(self.A.shape[2]):
            # for j in range(output_height-weight_height+1):
            for j in range(self.A.shape[3]):
                # print("dLdA shape is ",dLdA.shape)
                # print("dLdZ shape is ",dLdZ.shape)
                # print("Flipped Weight shape is ", flipped_weight.shape)
                # print("Shape of dLdZ portion that we will use is ",dLdZ[:,:,i:i+weight_width,j:j+weight_height].shape)
                # print("dLdA[:,:,i,j] shape we want is ",dLdA[:,:,i,j].shape)
                dLdA[:,:,i,j]=np.tensordot(dLdZ[:,:,i:i+weight_width,j:j+weight_height],flipped_weight,axes=[(1,2,3),(0,2,3)])
        #A: (batch_size, in_channels, input_width, input_height)  
        return dLdA

class Conv2d():
    def __init__(self, in_channels, out_channels, kernel_size, stride,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify the variable names
        self.stride = stride

        # Initialize Conv2d() and Downsample2d() isntance
        self.conv2d_stride1 =Conv2d_stride1(in_channels, out_channels,
                 kernel_size, weight_init_fn=None, bias_init_fn=None)
        self.downsample2d = Downsample2d(downsampling_factor=self.stride) # TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        # Call Conv2d_stride1
        # TODO

        # downsample
        Z = self.conv2d_stride1.forward(A)
        Z=self.downsample2d.forward(Z)
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        # Call downsample2d backward
        dLdZ=self.downsample2d.backward(dLdZ)
        dLdA = self.conv2d_stride1.backward(dLdZ)

        return dLdA

class ConvTranspose1d():
    def __init__(self, in_channels, out_channels, kernel_size, upsampling_factor,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.upsampling_factor = upsampling_factor

        # Initialize Conv1d stride 1 and upsample1d isntance
        #TODO
        self.upsample1d = Upsample1d(upsampling_factor=self.upsampling_factor)

        self.conv1d_stride1 = Conv1d_stride1(in_channels, out_channels, kernel_size,
                 weight_init_fn, bias_init_fn) # weight and bias needed for transposing

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """
        #TODO
        # upsample
        A_upsampled = self.upsample1d.forward(A) #TODO

        # Call Conv1d_stride1()
        Z = self.conv1d_stride1.forward(A_upsampled)  #TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        #TODO

        #Call backward in the correct order
        delta_out = self.conv1d_stride1.backward(dLdZ) #TODO

        dLdA =  self.upsample1d.backward(delta_out) #TODO

        return dLdA

class ConvTranspose2d():
    def __init__(self, in_channels, out_channels, kernel_size, upsampling_factor,
                weight_init_fn=None, bias_init_fn=None):
        # Do not modify this method
        self.upsampling_factor = upsampling_factor

        # Initialize Conv2d() isntance
        self.conv2d_stride1 =Conv2d_stride1(in_channels, out_channels,
                 kernel_size, weight_init_fn, bias_init_fn)
        self.upsample2d = Upsample2d(upsampling_factor=self.upsampling_factor) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_size)
        Return:
            Z (np.array): (batch_size, out_channels, output_size)
        """
        # upsample
        A_upsampled = self.upsample2d.forward(A) #TODO

        # Call Conv2d_stride1()
        Z = self.conv2d_stride1.forward(A_upsampled) #TODO

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_size)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_size)
        """
        #Call backward in correct order
        delta_out = self.conv2d_stride1.backward(dLdZ) #TODO

        dLdA = self.upsample2d.backward(delta_out) #TODO

        return dLdA

class Flatten():

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, in_width)
        Return:
            Z (np.array): (batch_size, in_channels * in width)
        """
        
        Z = A.reshape(A.shape[0],A.shape[1]*A.shape[2]) # TODO
        self.a,self.b,self.c=A.shape[0],A.shape[1],A.shape[2]
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch size, in channels * in width)
        Return:
            dLdA (np.array): (batch size, in channels, in width)
        """

        dLdA =dLdZ.reshape(self.a,self.b,self.c)

        return dLdA

