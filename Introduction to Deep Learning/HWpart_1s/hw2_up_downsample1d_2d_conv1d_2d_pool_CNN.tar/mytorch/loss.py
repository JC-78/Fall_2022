import numpy as np

class MSELoss:
    
    def forward(self, A, Y):
    
        self.A = A
        self.Y = Y
        N      = A.shape[0]
        C      = A.shape[1]
        #print("N is ",N)
        #print("C is ",C)
        se     = np.multiply((A-Y),(A-Y))# TODO
        sse    = N*se*C # TODO
        mse    = sse/(N*C)
        #print("Np.sum(mse) is ",np.sum(mse)/(N*C))
        mse1=np.sum(mse)/(N*C)
        return mse1
    
    def backward(self):
    
        dLdA = self.A-self.Y
        
        return dLdA

class CrossEntropyLoss:
    
    def forward(self, A, Y):
    
        self.A   = A
        self.Y   = Y
        N        = A.shape[0]
        C        = A.shape[1]
        Ones_C   = np.ones((C, 1), dtype="f")
        Ones_N   = np.ones((N, 1), dtype="f")
        # print("Ones_C is ",Ones_C)
        # print("exp(A) is ",np.exp(self.A))
        # print("dot product is ",np.dot(np.exp(self.A),Ones_C))
        # print("dot product is ",np.dot(np.exp(self.A),Ones_C).shape)

        print("dot product is ",np.dot(np.dot(np.exp(self.A),Ones_C),Ones_C.T))
        #self.softmax     = np.exp(A)/(np.exp(A) * Ones_C * Ones_C.T ) # TODO
        self.softmax     = np.exp(self.A)/ np.dot(np.dot(np.exp(self.A),Ones_C),Ones_C.T)
        crossentropy     = np.multiply(-Y,np.log(self.softmax)) # TODO
        sum_crossentropy = np.dot(np.dot(Ones_N.T,crossentropy),Ones_C) # TODO
        L = sum_crossentropy / N
        #* is for elementise multiplication 
        #np.matmul,np.dot,@ are same. For matrix. for vector of Nx1 or 1xN dimension.
        return L
    
    def backward(self):
    
        dLdA = self.softmax-self.Y # TODO
        
        return dLdA
