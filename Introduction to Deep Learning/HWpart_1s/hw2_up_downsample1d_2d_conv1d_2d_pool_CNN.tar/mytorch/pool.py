import numpy as np
from resampling import *

class MaxPool2d_stride1():

    def __init__(self, kernel):
        self.kernel = kernel

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        self.A=A
        batch_size, in_channels, input_width, input_height=A.shape
        Z=np.zeros((batch_size, in_channels, input_width-self.kernel+1, input_height-self.kernel+1))
        # self.maxIndex=np.zeros((batch_size, in_channels, input_width-self.kernel+1, input_height-self.kernel+1))
        for b in range(batch_size):
            for ic in range(in_channels):
                for i in range(Z.shape[2]):
                    for j in range(Z.shape[3]):
                        slices=A[b,ic,i:i+self.kernel,j:j+self.kernel]
                        item=np.max(slices)
                        Z[b,ic,i,j]=item
                        # self.maxIndex[b,ic,i,j]=np.unravel_index(np.argmax(slices),slices.shape)
        return Z
    
    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        batch_size, out_channels, output_width, output_height=dLdZ.shape
        # batch_size, in_channels, input_width, input_height=self.A.shape
        
        dLdA=np.zeros(self.A.shape)
        for b in range(batch_size):
            for ic in range(out_channels):
                for i in range(output_width):
                    for j in range(output_height):
                        slices=self.A[b,ic,i:i+self.kernel,j:j+self.kernel]
                        indexes=(slices==np.max(slices))
                        # print(indexes)
                        dLdA[b,ic,i:i+self.kernel,j:j+self.kernel]+=indexes*dLdZ[b,ic,i,j]
        return dLdA               


class MeanPool2d_stride1():

    def __init__(self, kernel):
        self.kernel = kernel

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        self.A=A
        batch_size, in_channels, input_width, input_height=A.shape
        Z=np.zeros((batch_size, in_channels, input_width-self.kernel+1, input_height-self.kernel+1))
        # self.maxIndex=np.zeros((batch_size, in_channels, input_width-self.kernel+1, input_height-self.kernel+1))
        
        for b in range(batch_size):
            for ic in range(in_channels):
                for i in range(Z.shape[2]):
                    for j in range(Z.shape[3]):
                        slices=A[b,ic,i:i+self.kernel,j:j+self.kernel]
                        item=np.mean(slices)
                        Z[b,ic,i,j]=item
                        # self.maxIndex[b,ic,i,j]=np.unravel_index(np.argmax(slices),slices.shape)
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        batch_size, out_channels, output_width, output_height=dLdZ.shape
        # batch_size, in_channels, input_width, input_height=self.A.shape
        in_channels=self.A.shape[1]
        dLdA=np.zeros(self.A.shape)
        #ex. 8x8 A and 3*3 kernel
        for b in range(batch_size):
            for oc in range(out_channels):
                for i in range(output_width): #8-3+1=6
                    for j in range(output_height): #8-3+1=6
                        dLdA[b,oc,i:i+self.kernel,j:j+self.kernel]+= (dLdZ[b,oc,i,j]/(self.kernel**2))
        return dLdA               

class MaxPool2d():

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride
        
        #Create an instance of MaxPool2d_stride1
        self.maxpool2d_stride1 = MaxPool2d_stride1(kernel=self.kernel) #TODO
        self.downsample2d = Downsample2d(downsampling_factor=self.stride) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        Z=self.maxpool2d_stride1.forward(A)
        Z=self.downsample2d.forward(Z)
        return Z
    
    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        dLdA=self.downsample2d.backward(dLdZ)
        dLdA=self.maxpool2d_stride1.backward(dLdA)
        return dLdA

class MeanPool2d():

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride

        #Create an instance of MaxPool2d_stride1
        self.meanpool2d_stride1 = MeanPool2d_stride1(kernel=self.kernel) #TODO
        self.downsample2d = Downsample2d(downsampling_factor=self.stride) #TODO

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """
        Z=self.meanpool2d_stride1.forward(A)
        Z=self.downsample2d.forward(Z)
        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        dLdA=self.downsample2d.backward(dLdZ)
        dLdA=self.meanpool2d_stride1.backward(dLdA)
        return dLdA
