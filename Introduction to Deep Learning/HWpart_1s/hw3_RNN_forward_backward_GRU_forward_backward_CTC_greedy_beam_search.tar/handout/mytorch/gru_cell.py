import numpy as np
from activation import *


class GRUCell(object):
    """GRU Cell class."""

    def __init__(self, in_dim, hidden_dim):
        self.d = in_dim
        self.h = hidden_dim
        h = self.h
        d = self.d
        self.x_t = 0

        self.Wrx = np.random.randn(h, d)
        self.Wzx = np.random.randn(h, d)
        self.Wnx = np.random.randn(h, d)

        self.Wrh = np.random.randn(h, h)
        self.Wzh = np.random.randn(h, h)
        self.Wnh = np.random.randn(h, h)

        self.brx = np.random.randn(h)
        self.bzx = np.random.randn(h)
        self.bnx = np.random.randn(h)

        self.brh = np.random.randn(h)
        self.bzh = np.random.randn(h)
        self.bnh = np.random.randn(h)

        self.dWrx = np.zeros((h, d))
        self.dWzx = np.zeros((h, d))
        self.dWnx = np.zeros((h, d))

        self.dWrh = np.zeros((h, h))
        self.dWzh = np.zeros((h, h))
        self.dWnh = np.zeros((h, h))

        self.dbrx = np.zeros((h))
        self.dbzx = np.zeros((h))
        self.dbnx = np.zeros((h))

        self.dbrh = np.zeros((h))
        self.dbzh = np.zeros((h))
        self.dbnh = np.zeros((h))

        self.r_act = Sigmoid()
        self.z_act = Sigmoid()
        self.h_act = Tanh()

        # Define other variables to store forward results for backward here

    def init_weights(self, Wrx, Wzx, Wnx, Wrh, Wzh, Wnh, brx, bzx, bnx, brh, bzh, bnh):
        self.Wrx = Wrx
        self.Wzx = Wzx
        self.Wnx = Wnx
        self.Wrh = Wrh
        self.Wzh = Wzh
        self.Wnh = Wnh
        self.brx = brx
        self.bzx = bzx
        self.bnx = bnx
        self.brh = brh
        self.bzh = bzh
        self.bnh = bnh

    def __call__(self, x, h_prev_t):
        return self.forward(x, h_prev_t)

    def forward(self, x, h_prev_t):
        """GRU cell forward.

        Input
        -----
        x: (input_dim)
            observation at current time-step.

        h_prev_t: (hidden_dim)
            hidden-state at previous time-step.

        Returns
        -------
        h_t: (hidden_dim)
            hidden state at current time-step.

        """
        self.x = x
        self.hidden = h_prev_t
        
        # Add your code here.
        # Define your variables based on the writeup using the corresponding
        # names below.
        a=np.dot(self.Wzx,x)
        b=np.dot(self.Wzh,h_prev_t)
        c=a+self.bzx
        e=b+self.bzh #cannot use d or h or x cuz already used.
        self.pre_z=c+e
        self.z=self.z_act(self.pre_z)
        #print(self.z.shape)
        a=np.dot(self.Wrx,x)
        b=np.dot(self.Wrh,h_prev_t)
        # a=self.Wrx*x
        # b=self.Wrh*h_prev_t
        self.pre_r=a+self.brx+b+self.brh
        self.r=self.r_act(self.pre_r)


        
        a=np.dot(self.Wnx,x)
        b=np.dot(self.Wnh,h_prev_t)
        # a=self.Wnh*h_prev_t
        # b=self.Wnx*x
        self.pre_n=a+self.bnx+ self.r*(b+self.bnh)
        self.n= self.h_act(    self.pre_n     )
        # print("(1-self.z) shape is ",(1-self.z))
        # print("self.r shape is ",self.r)
        # print("self z is ",self.z)
        # print("h prev t is ",h_prev_t)
        h_t=(1-self.z)*self.n+self.z*h_prev_t
        self.h_t=h_t
        #h_t=np.dot((1-self.z),self.r)+np.dot(self.z,h_prev_t)
        
        assert self.x.shape == (self.d,)
        assert self.hidden.shape == (self.h,)

        assert self.r.shape == (self.h,)
        assert self.z.shape == (self.h,)
        assert self.n.shape == (self.h,)
        assert h_t.shape == (self.h,) # h_t is the final output of you GRU cell.

        return h_t

    def backward(self, delta):
        """GRU cell backward.

        This must calculate the gradients wrt the parameters and return the
        derivative wrt the inputs, xt and ht, to the cell.

        Input
        -----
        delta: (hidden_dim)
                summation of derivative wrt loss from next layer at
                the same time-step and derivative wrt loss from same layer at
                next time-step.

        Returns
        -------
        dx: (1, input_dim)
            derivative of the loss wrt the input x.

        dh_prev_t: (1, hidden_dim)
            derivative of the loss wrt the input hidden h.

        """
        # 1) Reshape self.x and self.hidden to (input_dim, 1) and (hidden_dim, 1) respectively
        #    when computing self.dWs...
        # 2) Transpose all calculated dWs...
        # 3) Compute all of the derivatives
        # 4) Know that the autograder grades the gradients in a certain order, and the
        #    local autograder will tell you which gradient you are currently failing.

        # ADDITIONAL TIP:
        # Make sure the shapes of the calculated dWs and dbs  match the
        # initalized shapes accordingly

        
        dn=delta*(np.ones(self.z.shape)-self.z)
        dz=delta *(-self.n+self.hidden) #fine
        dr=dn*self.h_act.backward()*(      self.Wnh@self.hidden      +self.bnh   ) #fine

        # dldwnx+=np.dot( np.reshape(self.x, (1, -1)).T,dn*self.h_act.backward()).T
        dldwnx=np.dot( np.reshape(self.x, (-1, 1)),dn*self.h_act.backward()).T
        # item=dn*self.h_act.backward()
        # print("shape is ",item.shape )
        # item1=np.reshape(self.x, (1, -1))
        # print("shape1 is" ,item1.shape)
        # dldwnx=np.dot( item,item1)
        self.dWnx+=dldwnx #before transpose, it should be (5,2)

        dldwrx= np.dot( np.reshape(self.x, (-1, 1)),    dr*self.r_act.backward()   ).T
        self.dWrx+=dldwrx

        dldwzx= np.dot( np.reshape(self.x, (-1, 1)),dz*self.z_act.backward()).T
        self.dWzx+=dldwzx

        dldwrh=np.dot(np.reshape(self.hidden, (-1, 1)),dr*self.r_act.backward()).T
        self.dWrh+=dldwrh

        dldwzh=np.dot(np.reshape(self.hidden, (-1, 1)),dz*self.z_act.backward()).T
        self.dWzh+=dldwzh

        dldwnh=np.dot(np.reshape(self.hidden, (-1, 1)),dn*self.h_act.backward()*self.r).T
        self.dWnh+=dldwnh

        # dldbrx=np.dot(dr,self.z_act.backward())*1
        dldbrx=dr*self.r_act.backward()
        self.dbrx+=dldbrx[0]  #operand with shape (2,) doesn't match the broadcast shape (1,2) so index 0
        dldbzx=dz*self.z_act.backward()
        self.dbzx+=dldbzx[0]
        dldbnx=dn*self.h_act.backward()
        self.dbnx+=dldbnx[0]

        dldbrh=dr*self.r_act.backward()
        self.dbrh+=dldbrh[0]
        
        dldbzh=dz*self.z_act.backward()
        self.dbzh+=dldbzh[0]

        item=dn*self.h_act.backward()
        item=item[0]
        dldbnh=item*self.r
        self.dbnh+=dldbnh

        a=np.dot( dr *self.r_act.backward() ,self.Wrx)
        b=np.dot(     dz*self.z_act.backward(),self.Wzx) 
        c=np.dot(     dn*self.h_act.backward(),self.Wnx) 
        dx=a+b+c

        ### everything good till now
        a=np.dot(     dr*self.r_act.backward(),self.Wrh) 
        b=np.dot(     dz*self.z_act.backward(),self.Wzh) 
        c=np.dot(     dn*self.h_act.backward()*self.r,self.Wnh     ) 
        #r is not involved in matrix,whereas Wnh is
        #r is multiplied with product of w and h in forward.
        #consider the ordering in forward.
        d=delta*self.z
        # dh_prev_t=a+b+c+d
        dh_prev_t=a
        # dh_prev_t+=a
        dh_prev_t+=b
        dh_prev_t+=c
        dh_prev_t+=d


        assert dx.shape == (1, self.d)
        assert dh_prev_t.shape == (1, self.h)
        return dx, dh_prev_t
        
