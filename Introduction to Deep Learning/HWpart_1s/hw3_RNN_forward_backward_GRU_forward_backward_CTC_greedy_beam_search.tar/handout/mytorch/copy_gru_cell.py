import numpy as np
from activation import *


class GRUCell(object):
    """GRU Cell class."""

    def __init__(self, in_dim, hidden_dim):
        self.d = in_dim
        self.h = hidden_dim
        h = self.h
        d = self.d
        self.x_t = 0

        self.Wrx = np.random.randn(h, d)
        self.Wzx = np.random.randn(h, d)
        self.Wnx = np.random.randn(h, d)

        self.Wrh = np.random.randn(h, h)
        self.Wzh = np.random.randn(h, h)
        self.Wnh = np.random.randn(h, h)

        self.brx = np.random.randn(h)
        self.bzx = np.random.randn(h)
        self.bnx = np.random.randn(h)

        self.brh = np.random.randn(h)
        self.bzh = np.random.randn(h)
        self.bnh = np.random.randn(h)

        self.dWrx = np.zeros((h, d))
        self.dWzx = np.zeros((h, d))
        self.dWnx = np.zeros((h, d))

        self.dWrh = np.zeros((h, h))
        self.dWzh = np.zeros((h, h))
        self.dWnh = np.zeros((h, h))

        self.dbrx = np.zeros((h))
        self.dbzx = np.zeros((h))
        self.dbnx = np.zeros((h))

        self.dbrh = np.zeros((h))
        self.dbzh = np.zeros((h))
        self.dbnh = np.zeros((h))

        self.r_act = Sigmoid()
        self.z_act = Sigmoid()
        self.h_act = Tanh()

        # Define other variables to store forward results for backward here

    def init_weights(self, Wrx, Wzx, Wnx, Wrh, Wzh, Wnh, brx, bzx, bnx, brh, bzh, bnh):
        self.Wrx = Wrx
        self.Wzx = Wzx
        self.Wnx = Wnx
        self.Wrh = Wrh
        self.Wzh = Wzh
        self.Wnh = Wnh
        self.brx = brx
        self.bzx = bzx
        self.bnx = bnx
        self.brh = brh
        self.bzh = bzh
        self.bnh = bnh

    def __call__(self, x, h_prev_t):
        return self.forward(x, h_prev_t)

    def forward(self, x, h_prev_t):
        """GRU cell forward.

        Input
        -----
        x: (input_dim)
            observation at current time-step.

        h_prev_t: (hidden_dim)
            hidden-state at previous time-step.

        Returns
        -------
        h_t: (hidden_dim)
            hidden state at current time-step.

        """
        self.x = x
        self.hidden = h_prev_t
        
        # Add your code here.
        # Define your variables based on the writeup using the corresponding
        # names below.
        a=np.dot(self.Wzx,x)
        b=np.dot(self.Wzh,h_prev_t)
        c=a+self.bzx
        e=b+self.bzh #cannot use d or h or x cuz already used.
        self.pre_z=c+e
        self.z=self.z_act(self.pre_z)
        #print(self.z.shape)
        a=np.dot(self.Wrx,x)
        b=np.dot(self.Wrh,h_prev_t)
        # a=self.Wrx*x
        # b=self.Wrh*h_prev_t
        self.pre_r=a+self.brx+b+self.brh
        self.r=self.r_act(self.pre_r)


        
        a=np.dot(self.Wnx,x)
        b=np.dot(self.Wnh,h_prev_t)
        # a=self.Wnh*h_prev_t
        # b=self.Wnx*x
        self.pre_n=a+self.bnx+ self.r*(b+self.bnh)
        self.n= self.h_act(    self.pre_n     )
        # print("(1-self.z) shape is ",(1-self.z))
        # print("self.r shape is ",self.r)
        # print("self z is ",self.z)
        # print("h prev t is ",h_prev_t)
        h_t=(1-self.z)*self.n+self.z*h_prev_t
        self.h_t=h_t
        #h_t=np.dot((1-self.z),self.r)+np.dot(self.z,h_prev_t)
        
        assert self.x.shape == (self.d,)
        assert self.hidden.shape == (self.h,)

        assert self.r.shape == (self.h,)
        assert self.z.shape == (self.h,)
        assert self.n.shape == (self.h,)
        assert h_t.shape == (self.h,) # h_t is the final output of you GRU cell.

        return h_t

    def backward(self, delta):
        """GRU cell backward.

        This must calculate the gradients wrt the parameters and return the
        derivative wrt the inputs, xt and ht, to the cell.

        Input
        -----
        delta: (hidden_dim)
                summation of derivative wrt loss from next layer at
                the same time-step and derivative wrt loss from same layer at
                next time-step.

        Returns
        -------
        dx: (1, input_dim)
            derivative of the loss wrt the input x.

        dh_prev_t: (1, hidden_dim)
            derivative of the loss wrt the input hidden h.

        """
        # 1) Reshape self.x and self.hidden to (input_dim, 1) and (hidden_dim, 1) respectively
        #    when computing self.dWs...
        # 2) Transpose all calculated dWs...
        # 3) Compute all of the derivatives
        # 4) Know that the autograder grades the gradients in a certain order, and the
        #    local autograder will tell you which gradient you are currently failing.

        # ADDITIONAL TIP:
        # Make sure the shapes of the calculated dWs and dbs  match the
        # initalized shapes accordingly

        # dz=delta*self.z
        # dn=delta*self.n
        # dr=delta*self.r
        # dh=delta*self.h
        #h=self.hidden
        dn=delta*(np.ones(self.z.shape)-self.z)
        #dn=delta*(1-self.z) #fine
        dz=delta *(-self.n+self.hidden) #fine
        #dr=dn*   np.dot(  self.h_act.backward() , np.dot(self.Wnh,self.hidden)+self.bnh)
        #TA:look into dr. use dot instead of matmul. 
        #dr=dn*   np.dot(  self.h_act.backward() , np.dot(self.Wnh,self.hidden)+self.bnh)
        dr=dn*self.h_act.backward()*(      self.Wnh@self.hidden      +self.bnh   ) #fine

        print("dr shape is ",dr.shape) #it is and meant to be (1,2)
        print("original x shape is ",self.x.shape)
        print("reshaped x shape is ",np.reshape(self.x, (1, -1)).shape )
        dldwrx= np.outer( np.reshape(self.x, (1, -1)).T,    dr*self.r_act.backward()   ).T
        dldwrh=np.outer(np.reshape(self.hidden, (1, -1)).T,dr*self.r_act.backward()).T
        dldbrx=dr*self.z_act.backward()
        dldbrh=dr*self.r_act.backward()
        dldbrh=dldbrh.T.reshape(self.dbrh.shape)
        #dldwrx= np.dot( np.dot(dz,self.z_act.backward())  , np.reshape(self.x, (1, -1)))
        print("dldwrx shape",dldwrx.shape)
        # dldwrx= np.dot(  np.reshape(self.x, (1, -1)).T,      np.dot(dr,self.r_act.backward())     )

        dldwzx= np.outer( np.reshape(self.x, (1, -1)).T,dz*self.z_act.backward()).T
        dldwzh=np.outer(np.reshape(self.hidden, (1, -1)).T,dz*self.z_act.backward()).T
        dldbzx=dz*self.z_act.backward()
        #dldwzx=np.dot( np.dot(dz,self.z_act.backward())  , np.reshape(self.x, (1, -1)))
        print("dldwzx shape",dldwzx.shape)
        dldwnx= np.outer( np.reshape(self.x, (1, -1)).T,dn*self.h_act.backward()).T
        #dldwnx=np.dot( np.dot(dn,self.h_act.backward()) , np.reshape(self.x, (1, -1)))
        print("dldwnx shape",dldwnx.shape)
        #dldwrh=np.dot(    np.dot( dr,self.r_act.backward()),     np.reshape(self.hidden, (1, -1)))
        
        #dldwzh=np.dot(np.dot(dz,self.z_act.backward()) ,np.reshape(self.hidden, (1, -1)))
       
        #dldwnh=np.dot( np.dot(dn,self.h_act.backward()) ,    (self.r*np.reshape(self.hidden, (1, -1))))
        dldwnh=np.outer(np.reshape(self.hidden, (1, -1)).T,dn*self.h_act.backward()).T

        # dldbrx=np.dot(dr,self.z_act.backward())*1
        # dldbzx=np.dot(dz,self.z_act.backward())*1
        # dldbnx=np.dot(dn,self.h_act.backward())*1
        # dldbrh=np.dot( dr, self.r_act.backward())
        # dldbzh=np.dot( dz,self.z_act.backward())
         #this is fine. 
        dldbrx=dldbrx.T.reshape(self.dbrx.shape)
        
        dldbnx=dn*self.h_act.backward()
        
        dldbzh=dz*self.z_act.backward()
        item=dn*self.h_act.backward()
        item=item[0]
        dldbnh=item*self.r

        # dldbnh=dn*self.h_act.backward()*self.r
        #dldbnh=dn*np.dot(self.h_act.backward(),self.r)
        #dldbnh=dn*np.matmul(self.h_act.backward(),self.r)
        print("self.Wrx shape is ",self.Wrx.shape)
        print("wrx shape we calculated is ",dldwrx.shape)
        print("self.Wrh shape is",self.Wrh.shape)
        print("wrh shape we calculated is",dldwrh.shape)
        print("self.brx shape is ",self.brx.shape)
        print("brx shape we calculated is",dldbrx.shape)
        #print("reshaped of tranpose of bzh shape we calculated is",dldbzh.T.reshape(1,-1).shape) #(1,2)
        self.Wrx += dldwrx
        self.Wzx += dldwzx
        self.Wnx += dldwnx
        self.Wrh += dldwrh
        self.Wzh += dldwzh
        self.Wnh += dldwnh
        self.brx += dldbrx  #no need to tranpose bias part. 
        self.bzx += dldbzx
        self.bnx += dldbnx
        self.brh += dldbrh
        self.bzh += dldbzh
        
        # a=np.dot(     dr,np.dot(self.r_act.backward(),self.Wrx) )
        # b=np.dot(     dz,np.dot(self.z_act.backward(),self.Wzx) )
        # c=np.dot(     dn,np.dot(self.h_act.backward(),self.Wnx) )

        dx=0
        dh_prev_t=0
        #print("meow shape is ",np.matmul(self.r_act.backward().T,self.Wrx).shape)
        # a=dr*np.matmul(self.r_act.backward().T,self.Wrx)
        a=np.dot( dr *self.r_act.backward() ,self.Wrx)
        #a=dr*self.r_act.backward()*self.Wrx
        b=np.dot(     dz*self.z_act.backward(),self.Wzx) 
        c=np.dot(     dn*self.h_act.backward(),self.Wnx) 
        dx=a+b+c
        #dx=self.Wrx+self.Wzx+self.Wnx

        a=np.dot(     dr*self.r_act.backward(),self.Wrh) 
        b=np.dot(     dz*self.z_act.backward(),self.Wzh) 
        c=np.dot(     dn*self.h_act.backward(),self.r* self.Wnh     ) 

        dh_prev_t=a+b+c
        print("correct dx shape is ",( 1,self.d)) #(1,5)
        print("dx shape is ",dx.shape) #(2,5)
        print("correct dh_prev_t shape is ",( 1,self.h)) #(1,5)
        print("dh_prev_t shape is ",dh_prev_t.shape)
        assert dx.shape == (1, self.d)
        assert dh_prev_t.shape == (1, self.h)

        return dx, dh_prev_t
        
