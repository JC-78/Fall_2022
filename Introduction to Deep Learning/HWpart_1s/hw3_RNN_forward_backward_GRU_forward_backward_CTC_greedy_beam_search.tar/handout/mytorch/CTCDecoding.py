import numpy as np

class GreedySearchDecoder(object):

    def __init__(self, symbol_set):
        """
        
        Initialize instance variables

        Argument(s)
        -----------

        symbol_set [list[str]]:
            all the symbols (the vocabulary without blank)

        """

        self.symbol_set = symbol_set
        


    def decode(self, y_probs):
        """

        Perform greedy search decoding

        Input
        -----

        y_probs [np.array, dim=(len(symbols) + 1, seq_length, batch_size)]
            batch size for part 1 will remain 1, but if you plan to use your
            implementation for part 2 you need to incorporate batch_size

        Returns
        -------

        decoded_path [str]:
            compressed symbol sequence i.e. without blanks or repeated symbols

        path_prob [float]:
            forward probability of the greedy path

        """

        decoded_path = []
        blank = 0
        path_prob = 1

        # TODO:
        symbols_length, seq_length, batch_size= y_probs.shape
        # 1. Iterate over sequence length - len(y_probs[0])
        symbol_set=self.symbol_set
        symbol_set.insert(0,"")
        for i in range(len(y_probs[0])):
        # 2. Iterate over symbol probabilities
            res=np.zeros(symbols_length)
            for j in range(symbols_length):
                #blank is the first symbol
                a=y_probs[j,i]
                res[j]=a
            index=np.argmax(res)
            # 3. update path probability, by multiplying with the current max probability
            # 4. Select most probable symbol and append to decoded_path
            decoded_path.append(self.symbol_set[index])
            path_prob*=y_probs[index,i]

        # 5. Compress sequence (Inside or outside the loop)
        #blank, remove. Same character=same. 
        length=len(decoded_path)
        res=[]
        for i in range(length):
            item=decoded_path[i]
            if (i==0 and item!="" ):
                res.append(item)
            if (i>0 and item!=res[-1] and item!=""):
                res.append(item)
        decoded_path=res
        decoded_path=''.join(res)
        return decoded_path, path_prob
        


class BeamSearchDecoder(object):

    def __init__(self, symbol_set, beam_width):
        """

        Initialize instance variables

        Argument(s)
        -----------

        symbol_set [list[str]]:
            all the symbols (the vocabulary without blank)

        beam_width [int]:
            beam width for selecting top-k hypotheses for expansion

        """

        self.symbol_set = symbol_set
        self.beam_width = beam_width
    
    def initializePaths(self,SymbolSet,y):
        InitialBlankPathScore,InitialPathScore=dict(),dict()
        path=""
        InitialBlankPathScore[path]=y[0]
        InitialPathsWithFinalBlank=set()
        InitialPathsWithFinalBlank.add(path)
        InitialPathsWithFinalSymbol=set()
        for i in range(len(SymbolSet)):
            path=SymbolSet[i]
            InitialPathScore[path]=y[i+1]
            InitialPathsWithFinalSymbol.add(path)
        return InitialPathsWithFinalBlank, InitialPathsWithFinalSymbol,InitialBlankPathScore, InitialPathScore

    def ExtendWithBlank(self,PathsWithTerminalBlank, PathsWithTerminalSymbol, y,BlankPathScore,PathScore):
        UpdatedPathsWithTerminalBlank = set()
        UpdatedBlankPathScore = dict()
        for path in PathsWithTerminalBlank:
            UpdatedPathsWithTerminalBlank.add(path) # Set addition
            UpdatedBlankPathScore[path] = BlankPathScore[path]*y[0]
        for path in PathsWithTerminalSymbol:
    # If there is already an equivalent string in UpdatesPathsWithTerminalBlank# simply add the score. If not create a new entry
            if path in UpdatedPathsWithTerminalBlank:
                UpdatedBlankPathScore[path] += PathScore[path]* y[0]
            else:
                UpdatedPathsWithTerminalBlank.add(path) # Set addition
                UpdatedBlankPathScore[path] = PathScore[path] * y[0]
        return UpdatedPathsWithTerminalBlank,UpdatedBlankPathScore

    def ExtendWithSymbol(self,PathsWithTerminalBlank, PathsWithTerminalSymbol, SymbolSet, y,BlankPathScore, PathScore):
        UpdatedPathsWithTerminalSymbol = set()
        UpdatedPathScore = dict()
        length=len(SymbolSet)
        for path in PathsWithTerminalBlank:
            for i in range(length):
                newpath=path+SymbolSet[i]
                UpdatedPathsWithTerminalSymbol.add(newpath)
                UpdatedPathScore[newpath] = BlankPathScore[path] * y[i+1]

        for path in PathsWithTerminalSymbol:
            for i in range(length):
                item=SymbolSet[i]
                if item==path[-1]:
                    newpath=path
                else:
                    newpath=path+item
                if newpath in UpdatedPathsWithTerminalSymbol:
                    UpdatedPathScore[newpath] += PathScore[path] * y[i+1] 
                else:
                    UpdatedPathsWithTerminalSymbol.add(newpath)
                    UpdatedPathScore[newpath] = PathScore[path] * y[i+1]
        return UpdatedPathsWithTerminalSymbol,UpdatedPathScore

    def Prune(self,PathsWithTerminalBlank, PathsWithTerminalSymbol, BlankPathScore, PathScore, BeamWidth):
        PrunedBlankPathScore = dict()
        PrunedPathScore = dict()
        scorelist=[]
        for path in PathsWithTerminalBlank:
            scorelist.append(BlankPathScore[path]) 
        
        for path in PathsWithTerminalSymbol:
            scorelist.append(PathScore[path])
        #scorelist.sort(reverse=True)
        scorelist.sort(reverse=True)
        # print("scorelist",scorelist)
        # print("Beamwidth",BeamWidth)
        if BeamWidth<len(scorelist):
            # cutoff=scorelist[:BeamWidth]
            cutoff=scorelist[BeamWidth-1]
        else:
            cutoff=scorelist[-1]
        # print("cutoff",cutoff)
        PrunedPathsWithTerminalBlank = set()
        for p in PathsWithTerminalBlank:
            if BlankPathScore[p] >= cutoff:
                PrunedPathsWithTerminalBlank.add(p) # Set addition
                PrunedBlankPathScore[p] = BlankPathScore[p]
        # print("PrunedPathsWithTerminalBlank",PrunedPathsWithTerminalBlank)
        PrunedPathsWithTerminalSymbol = set()
        for p in PathsWithTerminalSymbol:
            if PathScore[p] >= cutoff:
                PrunedPathsWithTerminalSymbol.add(p) # Set addition
                PrunedPathScore[p] = PathScore[p]
        # print("PrunedPathsWithTerminalSymbol",PrunedPathsWithTerminalSymbol)
        return PrunedPathsWithTerminalBlank, PrunedPathsWithTerminalSymbol, PrunedBlankPathScore, PrunedPathScore

    def MergeIdenticalPaths(self,PathsWithTerminalBlank, BlankPathScore,PathsWithTerminalSymbol, PathScore):
        MergedPaths = PathsWithTerminalSymbol
        FinalPathScore = PathScore
        for p in PathsWithTerminalBlank:
            if p in MergedPaths:
                FinalPathScore[p] += BlankPathScore[p]
            else:
                MergedPaths.add(p) # Set addition
                FinalPathScore[p] = BlankPathScore[p]
        return MergedPaths,FinalPathScore
    def decode(self, y_probs):
        """
        
        Perform beam search decoding

        Input
        -----

        y_probs [np.array, dim=(len(symbols) + 1, seq_length, batch_size)]
			batch size for part 1 will remain 1, but if you plan to use your
			implementation for part 2 you need to incorporate batch_size

        Returns
        -------
        
        forward_path [str]:
            the symbol sequence with the best path score (forward probability)

        merged_path_scores [dict]:
            all the final merged paths with their scores

        """
        
        T = y_probs.shape[1]
        bestPath, FinalPathScore = [],[]
        #just for one element. so y_probs[:,0,0] instead of y_probs[:,0,]
        NewPathsWithTerminalBlank, NewPathsWithTerminalSymbol, NewBlankPathScore, NewPathScore = self.initializePaths(self.symbol_set, y_probs[:,0,0])
        #print(NewPathsWithTerminalBlank, NewBlankPathScore, NewPathsWithTerminalSymbol,NewPathScore)
        for t in range(1,T):
            PathsWithTerminalBlank, PathsWithTerminalSymbol, BlankPathScore, PathScore = self.Prune(NewPathsWithTerminalBlank, NewPathsWithTerminalSymbol, NewBlankPathScore, NewPathScore, self.beam_width)
            #print("after pruning",PathsWithTerminalBlank, PathsWithTerminalSymbol, BlankPathScore, PathScore,"\n")
            NewPathsWithTerminalBlank, NewBlankPathScore = self.ExtendWithBlank(PathsWithTerminalBlank,PathsWithTerminalSymbol, y_probs[:,t,0],BlankPathScore, PathScore)
            #print("after extending with blank",NewPathsWithTerminalBlank, NewBlankPathScore,"\n")
            NewPathsWithTerminalSymbol, NewPathScore = self.ExtendWithSymbol(PathsWithTerminalBlank,PathsWithTerminalSymbol, self.symbol_set, y_probs[:,t,0],BlankPathScore, PathScore) 
            #print("after extending with symbol",NewPathsWithTerminalSymbol, NewPathScore,"\n")
        MergedPaths, FinalPathScore = self.MergeIdenticalPaths(NewPathsWithTerminalBlank, NewBlankPathScore,NewPathsWithTerminalSymbol, NewPathScore)
        # print(FinalPathScore)
        # print(max(FinalPathScore, key=FinalPathScore.get))
        bestPath=max(FinalPathScore, key=FinalPathScore.get)
        return bestPath, FinalPathScore
