import numpy as np


class CTC(object):

    def __init__(self, BLANK=0):
        """

        Initialize instance variables

        Argument(s)
        -----------

        BLANK (int, optional): blank label index. Default 0.

        """

        # No need to modify
        self.BLANK = BLANK


    def extend_target_with_blank(self, target):
        """Extend target sequence with blank.

        Input
        -----
        target: (np.array, dim = (target_len,))
                target output
        ex: [B,IY,IY,F]

        Return
        ------
        extSymbols: (np.array, dim = (2 * target_len + 1,))
                    extended target sequence with blanks
        ex: [-,B,-,IY,-,IY,-,F,-]

        skipConnect: (np.array, dim = (2 * target_len + 1,))
                    skip connections
        ex: [0,0,0,1,0,0,0,1,0]
        """

        extended_symbols = [self.BLANK]
        for symbol in target:
            extended_symbols.append(symbol)
            extended_symbols.append(self.BLANK)

        N = len(extended_symbols)

        skip_connect=[0,0]
        count=0
        #print("extended symbols",extended_symbols)
        for i in range(N-2):
            if count%2==1:
                if extended_symbols[i]==extended_symbols[i-2]:
                    skip_connect.append(0)
                else:
                    skip_connect.append(1)
            else:
                skip_connect.append(0)
            count+=1

        # <---------------------------------------------

        extended_symbols = np.array(extended_symbols).reshape((N,))
        skip_connect = np.array(skip_connect).reshape((N,))

        return extended_symbols, skip_connect


    def get_forward_probs(self, logits, extended_symbols, skip_connect):
        """Compute forward probabilities.

        Input
        -----
        logits: (np.array, dim = (input_len, len(Symbols)))
                predict (log) probabilities

                To get a certain symbol i's logit as a certain time stamp t:
                p(t,s(i)) = logits[t, qextSymbols[i]]

        extSymbols: (np.array, dim = (2 * target_len + 1,))
                    extended label sequence with blanks

        skipConnect: (np.array, dim = (2 * target_len + 1,))
                    skip connections

        Return
        ------
        alpha: (np.array, dim = (input_len, 2 * target_len + 1))
                forward probabilities

        """

        S, T = len(extended_symbols), len(logits)
        alpha = np.zeros(shape=(T, S))
        # -------------------------------------------->
        # TODO: Intialize alpha[0][0]
        alpha[0][0]=logits[0][extended_symbols[0]]
        # TODO: Intialize alpha[0][1]
        alpha[0][1]=logits[0][extended_symbols[1]]
        # TODO: Compute all values for alpha[t][sym] where 1 <= t < T and 1 <= sym < S (assuming zero-indexing)
        for t in range(1,T):
            alpha[t,0]=alpha[t-1,0]*logits[t,extended_symbols[0]]
            for i in range(1,S):
                alpha[t,i]=alpha[t-1,i]+alpha[t-1,i-1]
                if ( (i>1) and (extended_symbols[i]!=extended_symbols[i-2]) ):
                    alpha[t,i]+=alpha[t-1,i-2]
                alpha[t,i]*=logits[t,extended_symbols[i]]
        
        # IMP: Remember to check for skipConnect when calculating alpha
        # <---------------------------------------------

        return alpha



    def get_backward_probs(self, logits, extended_symbols, skip_connect):
        """Compute backward probabilities.

        Input
        -----
        logits: (np.array, dim = (input_len, len(symbols)))
                predict (log) probabilities

                To get a certain symbol i's logit as a certain time stamp t:
                p(t,s(i)) = logits[t,extSymbols[i]]

        extSymbols: (np.array, dim = (2 * target_len + 1,))
                    extended label sequence with blanks

        skipConnect: (np.array, dim = (2 * target_len + 1,))
                    skip connections

        Return
        ------
        beta: (np.array, dim = (input_len, 2 * target_len + 1))
                backward probabilities
        
        """

        N, T = len(extended_symbols), len(logits)
        beta = np.zeros(shape=(T, N))
        betahat = np.zeros(shape=(T, N))

        # -------------------------------------------->
        # TODO
        # print("beta shape",beta.shape)
        # print("logits shape",logits.shape)
        # print(" extended symbols shape ",extended_symbols.shape)
        T_last_ind=T-1
        N_last_ind=N-1
        betahat[T_last_ind][N_last_ind]=logits[T_last_ind][extended_symbols[N_last_ind]]
        betahat[T_last_ind][N_last_ind-1]=logits[T_last_ind][extended_symbols[N_last_ind-1]]
        # betahat[T_last_ind][0:N_last_ind-2]=0

        for t in range(T_last_ind-1,-1,-1):
            betahat[t,N_last_ind]=betahat[t+1,N_last_ind]*logits[t][extended_symbols[N_last_ind]]
            for i in range(N_last_ind-1,-1,-1):
                betahat[t,i]=betahat[t+1,i]+betahat[t+1,i+1]
                if ( (i<N_last_ind-2) and (skip_connect[i+2]==1)):
                    betahat[t,i]+= betahat[t+1,i+2] 
                # if ( (i<=N_last_ind-2) and (extended_symbols[i]!=extended_symbols[i+2]) ):
                    #betahat[t,i]+=betahat[t+1,i+2]
                betahat[t,i]*=logits[t,extended_symbols[i]]
        for t in range(T_last_ind,-1,-1):
            for i in range(N_last_ind,-1,-1):
                beta[t,i]=betahat[t,i]/logits[t,extended_symbols[i]]
        #Your values:     [[1.35051877e-03 4.92684612e-03 4.79647050e-03 6.08699950e-03 6.08699950e-03]
        #Expected values: [[5.24697510e+01 2.20116417e+01 8.14496483e+00 4.06416351e-02 6.08699950e-03]
        # <--------------------------------------------

        return beta
        
        

    def get_posterior_probs(self, alpha, beta):
        """Compute posterior probabilities.

        Input
        -----
        alpha: (np.array, dim = (input_len, 2 * target_len + 1))
                forward probability

        beta: (np.array, dim = (input_len, 2 * target_len + 1))
                backward probability

        Return
        ------
        gamma: (np.array, dim = (input_len, 2 * target_len + 1))
                posterior probability

        """

        [T, S] = alpha.shape #alpha = np.zeros(shape=(T, S))
        gamma = np.zeros(shape=(T, S))
        sumgamma = np.zeros((T,))

        # -------------------------------------------->
        # TODO
        [logits_length,N]=beta.shape
        #N, T = len(extended_symbols), len(logits)
        #beta = np.zeros(shape=(T, N))
        for t in range(0,T):
            sumgamma[t]=0
            for i in range(0,N):
                gamma[t,i]=alpha[t,i]*beta[t,i]
                sumgamma[t]+=gamma[t,i]
            for i in range(0,N):
                gamma[t,i]=gamma[t,i]/sumgamma[t]

        
        
        # <---------------------------------------------

        return gamma
        


class CTCLoss(object):

    def __init__(self, BLANK=0):
        """

        Initialize instance variables

        Argument(s)
        -----------
        BLANK (int, optional): blank label index. Default 0.
        
        """
        # -------------------------------------------->
        # No need to modify
        super(CTCLoss, self).__init__()

        self.BLANK = BLANK
        self.gammas = []
        self.ctc = CTC()
        # <---------------------------------------------

    def __call__(self, logits, target, input_lengths, target_lengths):

        # No need to modify
        return self.forward(logits, target, input_lengths, target_lengths)

    def forward(self, logits, target, input_lengths, target_lengths):
        """CTC loss forward

        Computes the CTC Loss by calculating forward, backward, and
        posterior proabilites, and then calculating the avg. loss between
        targets and predicted log probabilities

        Input
        -----
        logits [np.array, dim=(seq_length, batch_size, len(symbols)]:
            log probabilities (output sequence) from the RNN/GRU

        target [np.array, dim=(batch_size, padded_target_len)]:
            target sequences

        input_lengths [np.array, dim=(batch_size,)]:
            lengths of the inputs

        target_lengths [np.array, dim=(batch_size,)]:
            lengths of the target

        Returns
        -------
        loss [float]:
            avg. divergence between the posterior probability and the target

        """

        # No need to modify
        self.logits = logits
        self.target = target
        self.input_lengths = input_lengths
        self.target_lengths = target_lengths

        #####  IMP:
        #####  Output losses will be divided by the target lengths
        #####  and then the mean over the batch is taken

        # No need to modify
        B, _ = target.shape
        total_loss = np.zeros(B)
        self.extended_symbols = []
        
        #print("target is ",target)
        # print("target shape" ,target.shape) #(12, 4)
        # print("target length",target_lengths) #[2 3 3 3 3 3 3 2 4 3 3 3]
        # print("logits shape",logits.shape) #(15, 12, 8)
        # print("input length",input_lengths) #[12 12 12 12 12 12 12 12 12 12 12 12]
        #B=12
        for batch_itr in range(B):
            # -------------------------------------------->
            # Computing CTC Loss for single batch
            # Process:
            #     Truncate the target to target length
            t=target[batch_itr,:target_lengths[batch_itr]]
            #     Truncate the logits to input length
            l=logits[:input_lengths[batch_itr],batch_itr,:]
            #     Extend target sequence with blank
            extended_symbols, skip_connect=self.ctc.extend_target_with_blank(t)
            self.extended_symbols.append(extended_symbols)
            #     Compute forward probabilities
            alpha=self.ctc.get_forward_probs(l,extended_symbols,skip_connect)
            #     Compute backward probabilities
            beta=self.ctc.get_backward_probs(l,extended_symbols,skip_connect)
            #     Compute posteriors using total probability function
            gamma=self.ctc.get_posterior_probs(alpha, beta)
            #     Compute expected divergence for each batch and store it in totalLoss
            self.gammas.append(gamma)
            T,R=gamma.shape
            value=0

            """
            gamma shape: Tx R
            gamma: (dim = (input_len, 2 * target_len + 1))
            logits (dim=(seq_length, batch_size, len(symbols)]:
            l=seq_length,len(symbols)

            r=0 specifies blank
            r=1 original symbol
            """
            for t in range(T):
                for r in range(R):
                    a=gamma[t,r]
                    # print("l shape",l.shape)
                    # print("extended_symbols[r]",extended_symbols[r])
                    b=np.log(   l[t,extended_symbols[r]] )
                    value+= (a*b)
            total_loss[batch_itr]= value*-1
            #     Take an average over all batches and return final result
        total_loss = np.sum(total_loss) / B
        return total_loss
        
        

    def backward(self):
        """
        
        CTC loss backard

        Calculate the gradients w.r.t the parameters and return the derivative 
        w.r.t the inputs, xt and ht, to the cell.

        Input
        -----
        logits [np.array, dim=(seqlength, batch_size, len(Symbols)]:
            log probabilities (output sequence) from the RNN/GRU

        target [np.array, dim=(batch_size, padded_target_len)]:
            target sequences

        input_lengths [np.array, dim=(batch_size,)]:
            lengths of the inputs

        target_lengths [np.array, dim=(batch_size,)]:
            lengths of the target

        Returns
        -------
        dY [np.array, dim=(seq_length, batch_size, len(extended_symbols))]:
            derivative of divergence w.r.t the input symbols at each time

        """

        # No need to modify
        T, B, C = self.logits.shape
        dY = np.full_like(self.logits, 0)
        print("dY shape",dY.shape)
        print("logit shape",self.logits.shape)
        print("B",B)
        for batch_itr in range(B):
            # -------------------------------------------->
            # Computing CTC Derivative for single batch
            # Process:
            #     Truncate the target to target length
            t=self.target[batch_itr,:self.target_lengths[batch_itr]]
            #     Truncate the logits to input length
            l=self.logits[:self.input_lengths[batch_itr],batch_itr,:]
            #     Extend target sequence with blank
            extended_symbols, skip_connect=self.ctc.extend_target_with_blank(t)
            #     Compute derivative of divergence and store them in dY
            # <---------------------------------------------

            alpha=self.ctc.get_forward_probs(l,extended_symbols,skip_connect)
            #     Compute backward probabilities
            beta=self.ctc.get_backward_probs(l,extended_symbols,skip_connect)
            #     Compute posteriors using total probability function
            gamma=self.ctc.get_posterior_probs(alpha, beta)
            
            T,R=gamma.shape
            for t in range(T):
                for r in range(R):
                    dY[t,batch_itr,extended_symbols[r]]-= gamma[t,r]/l[t,extended_symbols[r]]
            # -------------------------------------------->
            # TODO
            # <---------------------------------------------
            

        return dY
        
